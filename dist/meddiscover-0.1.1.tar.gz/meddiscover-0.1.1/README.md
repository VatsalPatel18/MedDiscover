# MedDiscover
MedDiscover is an AI-powered tool designed to assist biomedical researchers using RAG-LLM models fine-tuned on PubMed literature.
