from meddiscover.gradio_app import build_interface

if __name__ == "__main__":
    demo = build_interface()
    demo.launch()
